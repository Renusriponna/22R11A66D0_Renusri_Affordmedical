const mongoose = require("mongoose");

const shortUrlSchema = new mongoose.Schema({
  shortCode: { type: String, unique: true },
  longUrl: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  createdAt: { type: Date, default: Date.now },
  expiresAt: Date,
  clicks: { type: Number, default: 0 },
});

module.exports = mongoose.model("ShortUrl", shortUrlSchema);
