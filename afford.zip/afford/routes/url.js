const express = require("express");
const router = express.Router();
const shortid = require("shortid");

// In-memory store
const urlDatabase = new Map();

// POST /api/url/shorten
router.post("/shorten", (req, res) => {
  const { longUrl } = req.body;

  if (!longUrl) {
    return res.status(400).json({ error: "Please provide a valid longUrl" });
  }

  const code = shortid.generate();
  const shortUrl = `http://localhost:3000/${code}`;
  urlDatabase.set(code, longUrl);

  res.json({ longUrl, shortUrl, code });
});

// GET /:code
router.get("/:code", (req, res) => {
  const longUrl = urlDatabase.get(req.params.code);

  if (longUrl) {
    return res.redirect(longUrl);
  } else {
    return res.status(404).json({ error: "No URL found" });
  }
});

module.exports = router;
