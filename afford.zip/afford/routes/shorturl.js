const express = require("express");
const router = express.Router();
const Url = require("../models/Url");

// POST /api/shorten
router.post("/shorten", async (req, res) => {
  const { originalUrl, customCode } = req.body;

  if (!originalUrl || !customCode) {
    return res.status(400).json({ error: "Both fields are required" });
  }

  try {
    let url = await Url.findOne({ shortCode: customCode });

    if (url) {
      return res.status(409).json({ error: "Custom code already in use" });
    }

    url = new Url({
      originalUrl,
      shortCode: customCode,
    });

    await url.save();
    res.status(201).json({
      shortUrl: `http://localhost:3000/${customCode}`,
      originalUrl,
      clicks: 0,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// GET /:shortCode
router.get("/:shortCode", async (req, res) => {
  const { shortCode } = req.params;

  try {
    const url = await Url.findOne({ shortCode });

    if (url) {
      url.clicks++;
      await url.save();
      return res.redirect(url.originalUrl);
    }

    res.status(404).json({ error: "Short URL not found" });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
